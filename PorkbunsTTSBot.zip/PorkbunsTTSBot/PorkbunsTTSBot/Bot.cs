﻿using System;
using System.IO;
using TwitchLib.Client;
using TwitchLib.Client.Events;
using TwitchLib.Client.Models;
using TwitchLib.Communication.Clients;
using TwitchLib.Communication.Models;
using TwitchLib.Api;
using TwitchLib.PubSub;
using System.Speech.Synthesis;
using System.Speech.AudioFormat;

namespace PorkbunsTTSBot
{
    class Bot
    {
        private static TwitchClient client;
        SpeechSynthesizer voice = new SpeechSynthesizer();
        bool subs = true;
        bool raids = true;


        public Bot()
        {
            ConnectionCredentials credentials = new ConnectionCredentials("mrbot520", File.ReadAllText("1wfchgzzsu5otn5bpbx2p6xdpb1ek8"));
            var clientOptions = new ClientOptions
            {
                MessagesAllowedInPeriod = 750,
                ThrottlingPeriod = TimeSpan.FromSeconds(30)
            };

            WebSocketClient customClient = new WebSocketClient(clientOptions);
            client = new TwitchClient(customClient);
            client.Initialize(credentials, "panfriedporkbun");

            client.OnMessageReceived += Client_OnMessageReceived;
            client.OnChatCommandReceived += Client_OnChatCommandReceived;
            client.OnCommunitySubscription += Client_OnGiftedSubscription;
            client.OnNewSubscriber += Client_OnNewSubscriber;
            client.OnReSubscriber += Client_OnReSubscriber;
            client.OnRaidNotification += Client_OnRaidNotification;
            client.OnConnected += Client_OnConnected;
            client.OnLog += Client_OnLog;

            voice.SelectVoice("Microsoft Zira Desktop");

            client.Connect();
        }

        private void Client_OnReSubscriber(object sender, OnReSubscriberArgs e)
        {
            if (subs == true)
            {
                voice.Speak(e.ReSubscriber.DisplayName + " has subscribed!!");
            }
        }

        private void Client_OnNewSubscriber(object sender, OnNewSubscriberArgs e)
        {
            if (subs == true)
            {
                voice.Speak(e.Subscriber.DisplayName + " has subscribed!!");
            }
        }

        private void Client_OnGiftedSubscription(object sender, OnCommunitySubscriptionArgs e)
        {
            if (subs == true)
            {
                voice.Speak(e.GiftedSubscription.DisplayName + " gifted " + e.GiftedSubscription.MsgParamMassGiftCount + " subs!");
            }
        }

        private void Client_OnRaidNotification(object sender, OnRaidNotificationArgs e)
        {
            if (raids == true)
            {
                voice.Speak(e.RaidNotification.DisplayName + " has raided!!");
            }
        }

        private void Client_OnChatCommandReceived(object sender, OnChatCommandReceivedArgs e)
        {
            string commandTitle = e.Command.CommandText.ToLower();
            string commandArguments = e.Command.ArgumentsAsString.ToLower();

            if (commandTitle == "tts" && e.Command.ChatMessage.DisplayName == "mrjoshua520")
            {
                voice.Speak(commandArguments);
            }

            if (commandTitle == "raidoff")
            {
                raids = false;
            }
            else if (commandTitle == "raidon")
            {
                raids = true;
            }

            if (commandTitle == "suboff")
            {
                subs = false;
            }
            else if (commandTitle == "subon")
            {
                subs = true;
            }
        }

        private void Client_OnMessageReceived(object sender, OnMessageReceivedArgs e)
        {
            string message = e.ChatMessage.Message.ToLower();
            string user = e.ChatMessage.DisplayName.ToLower();

            if (e.ChatMessage.CustomRewardId == "feaa1076-f1b6-4c14-8d16-6873da1635e4")
            {
                voice.Speak(message); // TTS Redeem
            }
        }

        private void Client_OnConnected(object sender, OnConnectedArgs e)
        {
            //Console.WriteLine($"Connected to {e.AutoJoinChannel}");
        }

        private void Client_OnLog(object sender, OnLogArgs e)
        {
            //Console.WriteLine($"{e.DateTime.ToString()}: {e.BotUsername} - {e.Data}");
        }
    }
}
